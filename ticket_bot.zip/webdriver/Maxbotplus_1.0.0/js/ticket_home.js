$("#footer").remove();
$("footer").remove();
