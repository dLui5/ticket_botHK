$('input[type=checkbox]').each(function() {
   $(this).prop('checked', true);
});
