$("#newsHome").remove();
$("footer").remove();
$("#topAlert").remove();
$("div.darkBg > div.container > div.row").remove();